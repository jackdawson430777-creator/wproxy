# Third-party notices

## Mihomo
- Project: https://github.com/MetaCubeX/mihomo
- Version pinned by the initial workflow: `v1.19.33`
- Downloaded artifact: `mihomo-android-arm64-v8-v1.19.33.gz`
- SHA-256 of the compressed release artifact:
  `2ddbd3aaa884f52b4568f406876ec81dddeef9f1bb67b90d4004d356e2c6a708`
- Upstream license file: https://github.com/MetaCubeX/mihomo/blob/v1.19.33/LICENSE

The upstream repository's LICENSE should be checked at the exact pinned tag before redistributing binaries. The workflow verifies the release artifact hash published for v1.19.33, but this does not independently prove that upstream code is free of vulnerabilities.

The Mihomo binary is downloaded from the official MetaCubeX GitHub release during CI and embedded in the APK under `assets/`. It is not committed to this source archive.
