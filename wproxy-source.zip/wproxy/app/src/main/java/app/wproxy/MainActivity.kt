package app.wproxy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var configStatus: TextView
    private lateinit var rootStatus: TextView
    private lateinit var coreStatus: TextView

    companion object {
        private const val PICK_CONFIG = 4101
        private const val PREFS = "wproxy"
        private const val KEY_CONFIG = "config_path"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshConfigState()
        coreStatus.text = "Mihomo：CI 构建时打包 v1.19.33（arm64-v8a）"
        status.text = "阶段 1：界面与基础能力骨架。透明代理尚未启用。"
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        scroll.addView(content)
        content.addView(TextView(this).apply {
            text = "wproxy"
            textSize = 30f
            setTextColor(0xFF172033.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "Root 透明代理 · 开发预览"
            textSize = 14f
            setTextColor(0xFF586174.toInt())
            setPadding(0, dp(4), 0, dp(16))
        })

        status = addCard(content, "运行状态", "尚未启动")
        rootStatus = addCard(content, "Root 权限", "尚未检测")
        coreStatus = addCard(content, "代理核心", "检查中")
        configStatus = addCard(content, "配置文件", "尚未导入")

        addButton(content, "导入 Mihomo YAML 配置") { openConfigPicker() }
        addButton(content, "检测 Root 权限") { checkRoot() }
        addButton(content, "检查配置文件是否存在") { refreshConfigState() }

        content.addView(TextView(this).apply {
            text = "首版功能路线"
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF172033.toInt())
            setPadding(0, dp(20), 0, dp(8))
        })
        content.addView(TextView(this).apply {
            text = "• 订阅导入：当前支持选择本地 YAML 文件\n" +
                "• 地区策略组：后续读取 Mihomo Controller API\n" +
                "• 实时流量：后续接入核心流量 API\n" +
                "• DNS / IPv6：后续增加可验证的配置选项\n" +
                "• 指定应用代理：后续按 Android UID 生成规则\n" +
                "• 开机自动连接：尚未启用，待规则恢复机制完成后开发\n" +
                "• Root 透明代理：当前只做 Root 检测，未安装网络规则"
            textSize = 14f
            setTextColor(0xFF343D4E.toInt())
            setPadding(0, 0, 0, dp(12))
        })
        content.addView(TextView(this).apply {
            text = "安全提示：当前版本不会修改 iptables、路由表或系统 DNS。不要将此开发预览当作已可用的代理工具。"
            textSize = 13f
            setTextColor(0xFF8A3B18.toInt())
            setPadding(0, dp(10), 0, dp(10))
        })

        setContentView(scroll)
    }

    private fun addCard(parent: LinearLayout, title: String, initial: String): TextView {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        wrap.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(0xFF687286.toInt())
        })
        val value = TextView(this).apply {
            text = initial
            textSize = 16f
            setTextColor(0xFF172033.toInt())
            setPadding(0, dp(4), 0, 0)
        }
        wrap.addView(value)
        val lp = LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        }
        parent.addView(wrap, lp)
        return value
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(6)
        })
    }

    private fun openConfigPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, PICK_CONFIG)
    }

    @Deprecated("Deprecated by Android; kept for broad API compatibility in scaffold")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_CONFIG || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        executor.execute {
            try {
                val target = File(filesDir, "config.yaml")
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "无法读取所选文件" }
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_CONFIG, target.absolutePath).apply()
                runOnUiThread {
                    configStatus.text = "已导入到应用私有目录：config.yaml（尚未校验）"
                    Toast.makeText(this, "配置已复制；尚未进行语法校验", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "导入失败：" + (e.message ?: "未知错误"), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshConfigState() {
        val path = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_CONFIG, null)
        val file = path?.let(::File)
        configStatus.text = if (file != null && file.isFile) {
            "已导入：${file.name}（${file.length()} 字节；尚未校验）"
        } else {
            "尚未导入配置文件"
        }
    }

    private fun checkRoot() {
        rootStatus.text = "正在请求 Root 检测授权…"
        executor.execute {
            val result = try {
                val process = ProcessBuilder("su", "-c", "id")
                    .redirectErrorStream(true)
                    .start()
                val output = process.inputStream.bufferedReader().use { it.readText() }
                val exit = process.waitFor()
                if (exit == 0 && output.contains("uid=0")) {
                    "Root 可用：${output.trim()}"
                } else {
                    "未获得 Root 授权：${output.trim().ifBlank { "su exit=$exit" }}"
                }
            } catch (e: Exception) {
                "Root 检测失败：${e.message ?: "su 不可用"}"
            }
            runOnUiThread { rootStatus.text = result }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
