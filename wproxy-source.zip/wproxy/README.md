# wproxy

独立 Android Root 透明代理客户端的第一阶段工程骨架。

> 当前阶段：可构建的 UI / 配置导入 / Root 检测骨架。**尚未实现实际透明代理规则安装、DNS 劫持、按应用 UID 分流、开机恢复和流量统计**。不要把此阶段 APK 当作可用代理客户端。

## 技术方案
- Kotlin + Android Gradle Plugin
- 最低 Android API 26，目标 API 35
- 首版构建 ABI：`arm64-v8a`
- Mihomo：官方 `v1.19.33` Android ARM64 二进制，构建时下载并校验 SHA-256
- 在线构建：GitHub Actions

## 在线构建
1. 将整个目录上传到自己的 GitHub 仓库。
2. 打开仓库的 **Actions** 页面。
3. 运行 **Build wproxy APK** 工作流，或 push 到 `main`。
4. 构建成功后，在该次工作流的 Artifacts 下载 `wproxy-debug-apk`。

本工程没有提交 Gradle Wrapper JAR；工作流通过 `gradle/actions/setup-gradle` 安装 Gradle，因此不需要本地 Android 开发环境。

## 目前已实现
- wproxy 基础 Android 界面
- 从系统文件选择器导入 YAML 配置并保存到应用私有目录
- Root 可用性检测（只执行 `id` 检测，不修改系统）
- 展示当前打包的 Mihomo 版本
- 自动化构建下载 Mihomo 二进制并校验哈希

## 尚未实现（后续阶段）
- 解析、校验及安全规范化订阅配置
- Mihomo 进程启动/停止与 API 认证
- TPROXY / REDIRECT / fwmark / policy routing 规则
- IPv4/IPv6 DNS 接管及防回环
- 指定应用 UID 过滤
- 崩溃恢复、开机启动和可靠的规则清理
- 实时流量、地区策略组读写

## 安全设计原则
- 默认不请求 Root；用户主动点击 Root 检测时才触发授权请求。
- 不清空系统现有 iptables/nftables 规则。
- 只操作带有 wproxy 专用标识的链和路由表；停止时只清理本应用创建的规则。
- 不将订阅 URL、代理凭据或配置内容上传到任何第三方服务。
- 每次启用透明代理前先验证配置，启动失败必须回滚本应用安装的规则。
- 不把未经验证的外部脚本以 Root 权限直接执行。

## License
本仓库中的原创骨架代码采用 MIT License。Mihomo 是单独的第三方组件，版权和许可证见 `THIRD_PARTY_NOTICES.md`。请在分发前再次核对所使用版本的上游许可证及所有依赖的许可证。
